<div class="jumbotron" id="jumbotron">
  <div class="container">
    <h1 class="display-4">Kami Hadir Untuk Menghubungkan Anda Dengan Beragam Kopi Terbaik Di Indonesia</h1>
  </div>
</div>

<section class="tentang">
  <div class="container">
    <div class="row">

      <div class="col-sm-12">
        <h5>KAMI HADIR UNTUK MENGHUBUNGKAN ANDA DENGAN BERAGAM KOPI TERBAIK DI INDONESIA</h5>
        <p>Kopipedia hadir dengan tujuan untuk memudahkan Anda menemukan Kopi yang Anda inginkan. Kami juga ingin mengenalkan anda dengan kopi terbaik di Indonesia yang menyuguhkan keanekaragaman citarasa dan konsistensi dalam kopi yang akan Anda nikmati.</p>
        <br>
        <h5>KAMI HADIR UNTUK MENDUKUNG RUMAH SANGRAI DI INDONESIA</h5>
        <p>Kami senang melihat pertumbuhan rumah sangrai di Indonesia saat ini. Kami melihat pertumbuhan ini sebagai dampak positif yang dapat membantu meningkatkan pertumbuhan ekonomi petani kopi lokal dan masyarakat sekitarnya. Penyangrai kopi yang kami sajikan pada setiap pengiriman adalah seniman kopi yang berdedikasi menghasilkan kopi dengan kualitas terbaik.</p>
      </div>

      <div class="col-sm-12 text-center makasi">
        <p>Terimakasih Atas Partisipasi Anda.</p>
      </div>
    </div>
  </div>
</section>

</body>
</html>