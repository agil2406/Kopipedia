<div class="jumbotron">
  <div class="container text-center">
  	<img src="<?php echo ?>" width="230" class="text-center">
  </div>
</div>

<section class="akun">
	<div class="container">
		<div class="row">
			<div class="col-sm-2"></div>
			<div class="col-sm-8">
				<table class="table table-borderless tabel">
					<tr>
						<td>Nama</td>
						<td>:</td>
						<td>Lalu Farid</td>
					</tr>
					<tr>
						<td>alamat</td>
						<td>:</td>
						<td>Kampung Laku, Praya, Lombok Tengah, Nusa Tenggara Barat, Indonesia</td>
					</tr>
					<tr>
						<td>Nomor telepon</td>
						<td>:</td>
						<td>10957103719</td>
					</tr>
					<tr>
						<td>Email</td>
						<td>:</td>
						<td>lalufarid18@gmail.com</td>
					</tr>
				</table>
				<a class="btn btn-primary" href="edit.php">Edit Profil</a>
			</div>
			<div class="col-sm-2"></div>
		</div>
	</div>
</section>

<br><br><br>