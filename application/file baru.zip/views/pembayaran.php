<section class="informasi">
<div class="container-fluid">
	<br><br><br><br><br>
	<div class="alert alert-success">
		<p class="text-center align-middle"> Selamat Pesanan Anda Berhasil diproses !!</p>	
	</div>
	<br><br><br><br><br>
</div>
</section>						
					